package org.xnap.commons.i18n.testpackage.noresources;

public class HasNoOwnResources 
{

}
